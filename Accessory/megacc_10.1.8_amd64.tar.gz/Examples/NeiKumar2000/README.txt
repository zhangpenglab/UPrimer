====================================================================================================
*						     						   *
*				Molecular Evolution and Phylogenetics        			   *
*						by                           			   *
*				   Masatoshi Nei and Sudhir Kumar            			   *
*									     			   *	
*	http://www.amazon.com/Molecular-Evolution-Phylogenetics-Masatoshi-Nei/dp/0195135857/       *
*						     			     			   *
====================================================================================================

The folder NeiKumar2000/ contains the data files used in the examples for the book Molecular Evolution and Phylogenetics[1] and is placed here so that users who are interested in learning about MEGA can reproduce the examples in the book using these datasets.  The files are named in the following convention.

Pg[Page number of the example]_Chap_[Chapter number of the example]_[Example or Figure]_[Example or Figure Number]_Data.[Extension]

Example: Pg024_Chap_02_Exp_01_Data.meg
Is Example #1 in Chapter 2 on page 24, it is a mega formated file.

